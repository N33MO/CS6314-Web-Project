CS6314.002-Team14-Coffee&TeaDistributor

1. Demo video: please check this link: https://web.microsoftstream.com/video/afc81a05-b61d-4024-b221-6c0790f59064

2. Report file: please check this link: https://drive.google.com/file/d/1QloXXrUJrZ7wgSj3S_Uz8NV-rIwMbtvh/view?usp=sharing

3. In `CS6314-Web-Project` folder, you can use files in `database` folder to import MySQL database. The main page is index.php. The screenshots are in report file and the demo is in the video.

4. In `additional` folder we implement this project with react and express frameworks and REST api as operations, this is regarded as a further learning.