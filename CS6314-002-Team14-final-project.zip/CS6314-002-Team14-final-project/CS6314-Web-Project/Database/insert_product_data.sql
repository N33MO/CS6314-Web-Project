 INSERT INTO `product`
 ( `ProductID`, `Name`, `Price`, `Num`, `Category`, `Description`, `Image` , `Removed`) 
 VALUES
 ( '11', 'coffee1', '10', '30', 'coffee', 'This is coffee #1.', 'coffee1.jpg', '0'),
 ( '12', 'coffee2', '16', '355', 'coffee', 'This is coffee #2.', 'coffee2.jpg', '0' ), 
 ( '13', 'coffee3', '71', '360', 'coffee', 'This is coffee #3.', 'coffee3.jpg', '0' ),
 ( '14', 'coffee4', '8', '730', 'coffee', 'This is coffee #4.', 'coffee4.jpg', '0'), 
 ( '15', 'coffee5', '56', '320', 'coffee', 'This is coffee #5.', 'coffee5.jpg', '0' ),
 ( '16', 'coffee6', '10', '30', 'coffee', 'This is coffee #6.', 'coffee1.jpg', '0' ),
 ( '17', 'coffee7', '16', '355', 'coffee', 'This is coffee #7.', 'coffee2.jpg' , '0'), 
 ( '18', 'coffee8', '71', '360', 'coffee', 'This is coffee #8.', 'coffee3.jpg', '0' ),
 ( '19', 'coffee9', '8', '730', 'coffee', 'This is coffee #9.', 'coffee4.jpg' , '0'), 
 ( '40', 'coffee10', '56', '320', 'coffee', 'This is coffee #10.', 'coffee5.jpg' , '0'),
 ( '21', 'tea1', '33', '32', 'tea', 'This is tea #1.', 'tea1.jpg' , '0'), 
 ( '22', 'tea2', '15', '542', 'tea', 'This is tea #2.', 'tea2.jpg' , '0'), 
 ( '23', 'tea3', '62', '342', 'tea', 'This is tea #3.', 'tea3.jpg' , '0'), 
 ( '24', 'tea4', '52', '38', 'tea', 'This is tea #4.', 'tea4.jpg' , '0'), 
 ( '25', 'tea5', '77', '72', 'tea', 'This is tea #5.', 'tea5.jpg' , '0'), 
 ( '26', 'tea6', '33', '32', 'tea', 'This is tea #6.', 'tea1.jpg' , '0'), 
 ( '27', 'tea7', '15', '542', 'tea', 'This is tea #7.', 'tea2.jpg' , '0'), 
 ( '28', 'tea8', '62', '342', 'tea', 'This is tea #8.', 'tea3.jpg' , '0'), 
 ( '29', 'tea9', '52', '38', 'tea', 'This is tea #9.', 'tea4.jpg' , '0'), 
 ( '30', 'tea10', '77', '72', 'tea', 'This is tea #10.', 'tea5.jpg' , '0');