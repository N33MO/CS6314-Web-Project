module.exports = {
    'secretKey': '12345-67890-09876-54321',
    'mongoUrl': 'mongodb://localhost:27017/conFusion',
    'facebook': {
        clientID: '993097944512098',
        clientSecret: '4e181abf77be631b335bc118bafbb590'
    }
}